package exercise_1;

public class Q9_VowelOrConsonant 
{
	public static void main(String[] args) 
	{
		char ch = 'S';
		
		switch ( ch )
		{
		case 'a' :
		case 'e' :
		case 'i' :
		case 'o' :
		case 'u' :
		case 'A' :
		case 'E' :
		case 'I' :
		case 'O' :
		case 'U' :
	         
			 System.out.print(ch + " is vowel");
             break;
             
        default:
             System.out.print(ch + " is consonant");
		}
	}
}
