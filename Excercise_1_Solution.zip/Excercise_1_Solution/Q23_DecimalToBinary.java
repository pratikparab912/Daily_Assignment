package exercise_1;

public class Q23_DecimalToBinary 
{
	public static void main(String[] args) 
	{
		System.out.print(Integer.toBinaryString(10));
		System.out.print ("\n");
		System.out.print (Integer.toBinaryString(15));
	}
}
