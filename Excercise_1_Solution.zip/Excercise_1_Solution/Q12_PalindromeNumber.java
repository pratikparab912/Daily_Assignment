package exercise_1;

import java.util.Scanner;

public class Q12_PalindromeNumber 
{
	public static void main(String[] args) 
	{
        int num , revNum = 0 , originalNum;
		
		Scanner scan = new Scanner ( System.in ) ;
		
		System.out.print ( "Enter A Number : " );
		num = scan.nextInt() ;
		
		originalNum = num ;
		
		while ( num != 0 )
		{
			revNum = revNum * 10  +  num % 10 ;
			num = num / 10 ;
		}
		
		if ( originalNum == revNum )
		{
			System.out.print ("\n");
			System.out.print ( "Number is palindrome" );
		}
		else
		{
			System.out.print ("\n");
			System.out.print ( "Number is not palindrome" );
		}
	}
}
