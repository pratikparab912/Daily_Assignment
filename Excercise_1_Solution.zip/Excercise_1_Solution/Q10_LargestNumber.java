package exercise_1;

import java.util.Scanner ;

public class Q10_LargestNumber 
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner ( System.in ) ;
		
		System.out.print ( "Enter First Number : " );
		int n1 = scan.nextInt() ;
		
		System.out.print ( "\nEnter Second Number : " );
		int n2 = scan.nextInt() ;
		
		System.out.print ( "\nEnter Third Number : " );
		int n3 = scan.nextInt() ;
		
		if  ( n1 > n2 && n1 > n3 )
		{
			System.out.print ("\n");
			System.out.print (n1+ " is largest number.");
		}
		else if ( n2 > n3 && n2 > n1 )
		{
			System.out.print ("\n");
			System.out.print (n2+ " is largest number.");
		}
		else
		{
			System.out.print ("\n");
			System.out.print (n3+ " is largest number.");
		}
		
	}
}
