package exercise_1;

import java.util.Scanner;

public class Q24_FactorialUsingRecursion 
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner (System.in) ;
		
		System.out.print ("Enter A Number : ") ;
		int num = scan.nextInt();
		
		int fact = factorial(num) ;
		
		System.out.print ("Factorial Of " +num+ " is : " +fact);
	}
	
	public static int factorial ( int num )
	{
		if ( num > 1 )
		{
			return num * factorial(num-1) ;
		}
		else
		{
			return 1 ;
		}
	}
}
