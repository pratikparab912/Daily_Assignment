package exercise_1;

import java.util.Scanner ;

public class Q13_PrimeNumber 
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner ( System.in ) ;
		
		System.out.print ( "Enter A Number To Check Whether Is Prime Or Not : " );
		int num = scan.nextInt();
		
		boolean flag = false ;
		
		for ( int i = 2 ; i <= num/2 ; ++i )
		{
			if ( num%i == 0)
			{
				flag = true ;
				break;
			}
		}
		
		if (!flag)
		{
			System.out.print ("\n");
			System.out.print ( "Number is prime" );
		}
		else
		{
			System.out.print ("\n");
			System.out.print ( "Number is not prime" );
		}
	}
}
