package exercise_1;

import java.util.Scanner ;

public class Q7_SwappingNumbersUsingTemporaryVariable 
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner ( System.in ) ;
		
		System.out.print ( "Before Swapping" );
		
		System.out.print ( "\nEnter First Number : " );
		int num1 = scan.nextInt ( ) ;
		
		System.out.print ( "Enter Second Number : " );
		int num2 = scan.nextInt ( ) ;
		
		int temp ;
		
		temp = num1 ;
		num1 = num2 ;
		num2 = temp ;
		
		System.out.print ( "\nAfter Swapping") ;
		
		
		System.out.print ( "\nValue Of First Number : " +num1 );
		
		System.out.print ( "\nValue Of Second Number : " +num2 );
	}
}
