package exercise_1;

public class Q21_OctalToDecimal 
{
	public static void main(String[] args) 
	{
		System.out.print(Integer.parseInt("10", 8));
		System.out.print ("\n");
		System.out.print (Integer.parseInt("12", 8));
	}
}
