package exercise_1;

import java.util.Scanner;

public class Q5_FibonacciSeries 
{
	public static void main(String[] args) 
	{
        int num , first = 0 , second = 1 , next ;
		
		Scanner scan = new Scanner ( System.in ) ;
		
		System.out.print ( "Enter Number Of Terms To Be Printed In Fibonacci Series : " );
		num = scan.nextInt ( )  ;
		
		System.out.println ( "\nFibonacci Series : " );
		
		for ( int i = 0 ; i < num ; i ++ )
		{
			System.out.print (" " +first+ " +");
			next = first + second ;
			first = second ;
			second = next ;
		}
	}
}
