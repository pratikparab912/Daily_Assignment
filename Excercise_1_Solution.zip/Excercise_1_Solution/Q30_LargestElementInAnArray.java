package exercise_1;

import java.util.Scanner ;

public class Q30_LargestElementInAnArray 
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner ( System.in ) ;
		
		System.out.print ( "Enter Size Of Array : ");
		int n = scan.nextInt();
		
		int arr[] = new int [ n ] ;
		
		System.out.print ("\nEnter Elements Of An Array : ");
		
		for ( int i = 0 ; i < arr.length ; i++ )
		{
			arr[i] = scan.nextInt();
		}
		
		int large = arr[0] ;
		
		for ( int i = 0 ; i < arr.length ; i++ )
		{
			if ( arr[i] > large )
			{
				large = arr[i];
			}
		}
		
		System.out.print ("\nLargest Element In An Array is : " +large);
		
	}
}
