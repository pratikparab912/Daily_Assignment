package exercise_1;

import java.util.Scanner;

public class Q2_ToCheckNumberPositiveOrNegative 
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner (System.in);
		
		System.out.print("Enter A Number To Check Whether Positive Or Not : ");
		double num = scan.nextDouble() ;
		
		if ( num > 0.0 )
		{
			System.out.print("\n");
			System.out.print(num+ " is a positive number.");
		}
		else if ( num < 0.0 )
		{
			System.out.print("\n");
			System.out.print(num+ " is a negative number.");
		}
		else
		{
			System.out.print("\n");
			System.out.print(num+ " is a 0.");
		}
	}
}
