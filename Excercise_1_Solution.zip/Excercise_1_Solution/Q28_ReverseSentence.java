package exercise_1;

public class Q28_ReverseSentence 
{
	public static void main(String[] args) 
	{
		String str = "CDAC Mumbai" ;
		
		String rev = reverse(str) ;
		
		System.out.print ("Reversed Sentence is : " +rev);
	}
	
	public static String reverse(String str) 
	{
	    if (str.isEmpty())
	      return str;

	    return reverse(str.substring(1)) + str.charAt(0);
	  }
}
