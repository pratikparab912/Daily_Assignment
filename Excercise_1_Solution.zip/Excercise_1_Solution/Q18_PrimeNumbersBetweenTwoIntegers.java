package exercise_1;

import java.util.Scanner;

public class Q18_PrimeNumbersBetweenTwoIntegers 
{
	public static void main(String[] args) 
	{
        Scanner scan = new Scanner ( System.in ) ;
		
		System.out.print ( "Enter Lowest Bound : " );
		int low = scan.nextInt();
		
		System.out.print ( "\nEnter Upper Bound : " );
		int high = scan.nextInt();
		
		System.out.print ("\n");
		
		while ( low < high )
		{
			boolean flag = false ;
			
			for ( int  i = 2 ; i <= low/2 ; ++i )
			{
				if ( low%i == 0 )
				{
					flag = true ;
					break ;
				}
			}
			
			if (!flag && low != 0 && low!= 1 )
			{
				System.out.print (low+ " ");
			}
			
			++low ;
		}
	}
}
