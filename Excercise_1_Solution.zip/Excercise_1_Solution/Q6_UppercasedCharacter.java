package exercise_1;

public class Q6_UppercasedCharacter 
{
	public static void main(String[] args) 
	{
		char c ;
		
		for ( c = 'A' ; c <= 'Z' ; ++c )
		{
			System.out.print ( c+ " ");
		}	
	}
}
