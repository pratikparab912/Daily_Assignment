package exercise_1;

import java.util.Scanner ;

public class Q3_FactorialOfNumber 
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner (System.in) ;
		
		System.out.print ( "Enter A Number To Find Out It's Factorial : " ) ;
		int num = scan.nextInt ( ) ;
		
		int fact = num ;
		
		while ( num > 1 )
		{
			num-- ;
			fact = fact * num ;
		}
		
		System.out.print ( "\nFactorial of given number is : " +fact);
	}
}
