package exercise_1;

public class Q20_DecimalToOctal 
{
	public static void main(String[] args) 
	{
		System.out.print (Integer.toOctalString(8));
		System.out.print("\n");
		System.out.print(Integer.toOctalString(10));
	}
}
