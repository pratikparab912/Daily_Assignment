package exercise_1;

import java.util.Scanner ;

public class Q15_ArmstrongNumberThreeDigitNumber 
{
	public static void main(String[] args) 
	{
		int num , originalNum , remainder , result = 0 ;
		
		Scanner scan = new Scanner ( System.in ) ;
		
		System.out.print ( "Enter A Three Digit Number : " );
		num = scan.nextInt();
		
		originalNum = num ;
		
		while ( originalNum != 0 )
		{
			remainder = originalNum % 10 ;
			result += Math.pow(remainder, 3) ;
			originalNum /= 10 ;
		}
		
		if ( result == num )
		{
			System.out.print ("\n");
			System.out.print (num+ " is an Armstrong Number.");
		}
		else
		{
			System.out.print ("\n");
			System.out.print (num+ " is not an Armstrong Number.");
		}
	}
}
