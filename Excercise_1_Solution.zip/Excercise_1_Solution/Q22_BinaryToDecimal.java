package exercise_1;

public class Q22_BinaryToDecimal 
{
	public static void main(String[] args) 
	{
		System.out.print (Integer.parseInt("1010",2));
		System.out.print ("\n");
		System.out.print (Integer.parseInt("1111", 2));
	}
}
