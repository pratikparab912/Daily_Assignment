package exercise_1;

import java.util.Scanner ;

public class Q11_ReverseNumber 
{
	public static void main(String[] args) 
	{
		int num , revNum = 0 ;
		
		Scanner scan = new Scanner ( System.in ) ;
		
		System.out.print ( "Enter A Number : " );
		num = scan.nextInt() ;
		
		while ( num != 0 )
		{
			revNum = revNum * 10  +  num % 10 ;
			num = num / 10 ;
		}
		
		System.out.print ( "Reversed Number is : " +revNum);
	}
}
